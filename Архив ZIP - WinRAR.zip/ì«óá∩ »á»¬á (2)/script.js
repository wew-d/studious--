document.getElementById("newsButton").addEventListener("click", function() {
    window.location.href = "news.html";
});
